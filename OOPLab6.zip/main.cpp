#include "teste.h"
#include "inout.h"
using namespace std;

int main() {
    testPoint();
    testDreptunghi();
    testUtils();
    run_menu();


}
