//
// Created by Alexe Andra on 04.04.2023.
//

#ifndef OOPLAB6_TESTE_H
#define OOPLAB6_TESTE_H
void testPoint();
void testDreptunghi();
void testUtils();
#endif //OOPLAB6_TESTE_H
