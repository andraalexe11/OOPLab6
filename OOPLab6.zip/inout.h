//
// Created by Alexe Andra on 04.04.2023.
//

#ifndef OOPLAB6_INOUT_H
#define OOPLAB6_INOUT_H
#include <vector>
#include "dreptunghi.h"
using namespace std;
void run_menu();
void entitati_egale(vector<Dreptunghi> v, int l, int& start, int& stop);
#endif //OOPLAB6_INOUT_H
